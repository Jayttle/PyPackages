from setuptools import setup, find_packages

setup(
    name='JayttleProcess',
    version='0.3.2',
    description='en: Data Process;\nzh_CN:数据处理的方法',
    packages=['JayttleProcess'],  # 指定包名列表
    author='Jayttle',
    author_email='294448068@qq.com',
    url="https://github.com/Jayttle/PyPackages.git",
    license='',
)